"""Persistência: conexão SQLite, esquema orientado a metadados e dados iniciais."""
import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "ghost.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS collections(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT DEFAULT '', icon TEXT DEFAULT '◈',
  color TEXT DEFAULT '#4fd1ff', position INTEGER DEFAULT 0, archived INTEGER DEFAULT 0,
  settings TEXT DEFAULT '{}', created_at TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS fields(
  id TEXT PRIMARY KEY, collection_id TEXT NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  name TEXT NOT NULL, description TEXT DEFAULT '', type TEXT NOT NULL, required INTEGER DEFAULT 0,
  default_value TEXT, options TEXT DEFAULT '{}', position INTEGER DEFAULT 0,
  hidden INTEGER DEFAULT 0, is_primary INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS records(
  id TEXT PRIMARY KEY, collection_id TEXT NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  created_at TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS record_values(
  record_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
  field_id TEXT NOT NULL REFERENCES fields(id) ON DELETE CASCADE,
  value TEXT NOT NULL, text_value TEXT, num_value REAL, PRIMARY KEY(record_id, field_id));
CREATE INDEX IF NOT EXISTS idx_rv_field ON record_values(field_id, num_value);
CREATE INDEX IF NOT EXISTS idx_rec_col ON records(collection_id);
CREATE TABLE IF NOT EXISTS relationship_defs(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, source_collection_id TEXT REFERENCES collections(id) ON DELETE CASCADE,
  target_collection_id TEXT REFERENCES collections(id) ON DELETE CASCADE,
  cardinality TEXT NOT NULL, directed INTEGER DEFAULT 1, required INTEGER DEFAULT 0,
  attributes TEXT DEFAULT '[]', created_at TEXT);
CREATE TABLE IF NOT EXISTS relationships(
  id TEXT PRIMARY KEY, def_id TEXT REFERENCES relationship_defs(id) ON DELETE CASCADE,
  source_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
  target_id TEXT NOT NULL REFERENCES records(id) ON DELETE CASCADE,
  label TEXT, start_date TEXT, end_date TEXT, notes TEXT, attributes TEXT DEFAULT '{}', created_at TEXT);
CREATE TABLE IF NOT EXISTS files(
  id TEXT PRIMARY KEY, original_name TEXT, mime TEXT, size INTEGER, stored_name TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS history(
  id INTEGER PRIMARY KEY AUTOINCREMENT, entity TEXT, entity_id TEXT, action TEXT, detail TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
"""

# Coleções iniciais: (nome, ícone, cor, [(campo, tipo, opções)]). O primeiro campo é o principal.
SEED = [
    ("Pessoas", "◉", "#4fd1ff", [("Nome", "short_text", {}), ("Apelidos", "tags", {}), ("Aniversário", "date", {}),
                                 ("Ocupação", "short_text", {}), ("Redes sociais", "long_text", {}),
                                 ("Foto", "file", {}), ("Observações", "long_text", {})]),
    ("Diário", "✎", "#7aa2ff", [("Título", "short_text", {}), ("Conteúdo", "long_text", {}),
                                ("Data do acontecimento", "date", {}), ("Categoria", "select", {"choices": []})]),
    ("Interesses", "✦", "#9be7c4", [("Nome", "short_text", {}), ("Descrição", "long_text", {})]),
    ("Grupos", "⬡", "#c9a7ff", [("Nome", "short_text", {}), ("Descrição", "long_text", {})]),
]


def new_id(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect(path=None):
    conn = sqlite3.connect(path or DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def log(conn, entity, entity_id, action, detail=""):
    conn.execute("INSERT INTO history(entity,entity_id,action,detail,at) VALUES(?,?,?,?,?)",
                 (entity, entity_id, action, detail, now()))


def init_db(path=None):
    """Cria tabelas e dados iniciais na primeira execução; nunca apaga dados existentes."""
    p = path or DB_PATH
    os.makedirs(os.path.dirname(p), exist_ok=True)
    conn = connect(p)
    with conn:
        conn.executescript(SCHEMA)
        if conn.execute("SELECT 1 FROM settings WHERE key='seeded'").fetchone():
            return conn
        t = now()
        for pos, (name, icon, color, fields) in enumerate(SEED):
            cid = new_id("col")
            conn.execute("INSERT INTO collections(id,name,icon,color,position,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                         (cid, name, icon, color, pos, t, t))
            for i, (fname, ftype, opts) in enumerate(fields):
                conn.execute("INSERT INTO fields(id,collection_id,name,type,options,position,is_primary,required) VALUES(?,?,?,?,?,?,?,?)",
                             (new_id("fld"), cid, fname, ftype, json.dumps(opts), i, int(i == 0), int(i == 0)))
        conn.execute("INSERT INTO settings(key,value) VALUES('seeded','1')")
    return conn
